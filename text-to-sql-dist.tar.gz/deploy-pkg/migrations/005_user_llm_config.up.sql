ALTER TABLE users ADD COLUMN llm_config JSONB DEFAULT '{}'::jsonb;
