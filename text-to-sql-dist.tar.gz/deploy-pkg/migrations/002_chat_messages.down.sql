DROP TABLE IF EXISTS chat_messages;
