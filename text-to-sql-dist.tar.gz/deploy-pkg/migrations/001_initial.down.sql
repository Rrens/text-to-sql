-- 001_initial.down.sql
DROP TABLE IF EXISTS audit_log;
DROP TABLE IF EXISTS workspace_llm_config;
DROP TABLE IF EXISTS connections;
DROP TABLE IF EXISTS workspace_members;
DROP TABLE IF EXISTS workspaces;
DROP TABLE IF EXISTS users;
